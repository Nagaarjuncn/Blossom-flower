const video = document.getElementById("video");
const canvas = document.getElementById("overlay");
const ctx = canvas.getContext("2d");
const startBtn = document.getElementById("startBtn");
const flowerWorld = document.getElementById("flowerWorld");
const message = document.getElementById("message");
const status = document.getElementById("status");
const dot = document.getElementById("statusDot");
const errorBox = document.getElementById("error");

let camera = null;
let mode = "idle";
let lastRightPinch = 0;
let lastLeftPinch = 0;

function setStatus(text, active=false) {
  status.textContent = text;
  dot.classList.toggle("active", active);
}

function setMode(next) {
  if (mode === next) return;
  mode = next;
  flowerWorld.classList.toggle("flower-mode", mode === "flower" || mode === "blossom");
  flowerWorld.classList.toggle("blossom-mode", mode === "blossom");
  const labels = {
    idle: "Raise either hand",
    bud: "Bud is growing 🌱",
    flower: "Right-hand pinch → flower 🌸",
    blossom: "Left-hand pinch → blossom ✨"
  };
  message.textContent = labels[mode];
}

function dist(a,b){ return Math.hypot(a.x-b.x, a.y-b.y); }

function isPinching(hand) {
  // MediaPipe landmarks: thumb tip 4, index tip 8.
  return dist(hand[4], hand[8]) < 0.055;
}

function isRaisedHand(hand) {
  // A simple prototype heuristic: index and middle fingertips are above their MCP joints.
  return hand[8].y < hand[5].y && hand[12].y < hand[9].y;
}

function drawHands(results) {
  canvas.width = video.videoWidth || 1280;
  canvas.height = video.videoHeight || 720;
  ctx.clearRect(0,0,canvas.width,canvas.height);
  if (!results.multiHandLandmarks) return;

  for (let i=0;i<results.multiHandLandmarks.length;i++) {
    const landmarks = results.multiHandLandmarks[i];
    // The canvas is mirrored through CSS, matching the video.
    drawConnectors(ctx, landmarks, HAND_CONNECTIONS, {color:"#b8ef77", lineWidth:3});
    drawLandmarks(ctx, landmarks, {color:"#fff", lineWidth:1, radius:3});
  }
}

function onResults(results) {
  drawHands(results);

  const hands = results.multiHandLandmarks || [];
  const handedness = results.multiHandedness || [];
  let raised = false, rightPinch = false, leftPinch = false;

  hands.forEach((hand, i) => {
    const label = handedness[i]?.label; // With mirrored display, MediaPipe's label still identifies the user's hand.
    if (isRaisedHand(hand)) raised = true;
    if (label === "Right" && isPinching(hand)) rightPinch = true;
    if (label === "Left" && isPinching(hand)) leftPinch = true;
  });

  const now = performance.now();

  if (raised && mode === "idle") {
    setMode("bud");
    setStatus("Hand detected — bud active", true);
  }

  if (rightPinch && now-lastRightPinch > 900 && (mode === "bud" || mode === "idle")) {
    lastRightPinch = now;
    setMode("flower");
    setStatus("Right pinch detected — flower formed", true);
  }

  if (leftPinch && now-lastLeftPinch > 900 && mode === "flower") {
    lastLeftPinch = now;
    setMode("blossom");
    setStatus("Left pinch detected — blossom complete", true);
  }

  if (!hands.length) {
    if (mode === "idle") setStatus("Camera running — show a hand");
  }
}

async function startCamera() {
  errorBox.textContent = "";
  try {
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error("Camera access is not supported in this browser.");
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      video: { width: {ideal:1280}, height: {ideal:720}, facingMode:"user" },
      audio: false
    });
    video.srcObject = stream;
    await video.play();

    const hands = new Hands({
      locateFile: file => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
    });

    hands.setOptions({
      maxNumHands: 2,
      modelComplexity: 1,
      minDetectionConfidence: 0.6,
      minTrackingConfidence: 0.55
    });
    hands.onResults(onResults);

    camera = new Camera(video, {
      onFrame: async () => { await hands.send({image: video}); },
      width: 1280,
      height: 720
    });
    camera.start();

    startBtn.textContent = "Camera Running";
    startBtn.disabled = true;
    startBtn.style.opacity = ".65";
    setMode("idle");
    setStatus("Camera running — show a hand", true);
  } catch (err) {
    console.error(err);
    errorBox.textContent = "Camera could not start. Allow camera permission and open this prototype from localhost or HTTPS.";
    setStatus("Camera error");
  }
}

startBtn.addEventListener("click", startCamera);
