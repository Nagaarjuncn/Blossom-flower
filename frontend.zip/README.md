# Hand Flower Prototype

A browser prototype using the laptop webcam and MediaPipe Hands.

## Interaction

1. Click **Start Camera** and allow camera permission.
2. Raise either hand → a green bud appears.
3. Pinch **right thumb + right index finger** → the bud changes into a flower.
4. Pinch **left thumb + left index finger** → the flower blossoms.

## Important: run it through localhost

Modern browsers generally block camera access from a plain `file://` page. Use a local web server.

### Option A — Python

From this folder:

```bash
python -m http.server 8000
```

Then open:

http://localhost:8000

### Option B — VS Code

Install the **Live Server** extension, right-click `index.html`, and choose **Open with Live Server**.

## Notes

- The hand tracking uses MediaPipe Hands loaded from jsDelivr.
- The prototype is intentionally front-end only.
- The hand gesture detection is heuristic and can be tuned in `script.js`.
- If the right/left hand labels appear reversed for your camera setup, swap `"Right"` and `"Left"` in `script.js`.
