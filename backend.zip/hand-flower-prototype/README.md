# Gesture Flower Prototype 🌸

A browser-based prototype that uses your webcam and hand tracking
(Google MediaPipe Hands) to grow a flower with hand gestures:

1. **Raise either hand** in front of the camera → a bud appears.
2. **Pinch your RIGHT hand's thumb and index finger** together → the bud turns into a flower.
3. **Pinch your LEFT hand's thumb and index finger** together → the flower fully blossoms.

Everything runs **locally in your browser** — no server-side processing, no
data ever leaves your machine. "Backend" logic here means the hand-tracking
and gesture state machine (`script.js`), which drives what gets drawn.

## Files

- `index.html` — page layout (video + canvas)
- `style.css` — styling
- `script.js` — camera setup, MediaPipe Hands integration, pinch detection,
  the bud → flower → blossom state machine, and canvas drawing
- `README.md` — this file

## How to run it

Browsers require a "secure context" (HTTPS or `localhost`) to grant camera
access, so you can't just double-click `index.html` from disk in most
browsers — you need a tiny local web server. Pick whichever you have handy:

### Option A — Python (usually pre-installed)
```bash
cd hand-flower-prototype
python3 -m http.server 8000
```
Then open **http://localhost:8000** in Chrome or Edge.

### Option B — Node.js
```bash
cd hand-flower-prototype
npx serve .
```
Then open the URL it prints (something like http://localhost:3000).

### Option C — VS Code
Install the "Live Server" extension, right-click `index.html`, choose
"Open with Live Server".

When the page loads, allow camera access when prompted.

## Notes / tuning

- Hand tracking model and utilities are loaded from the MediaPipe CDN
  (`@mediapipe/hands`, `@mediapipe/camera_utils`, `@mediapipe/drawing_utils`),
  so you need an internet connection the first time (browser caches after that).
- Pinch sensitivity is controlled by `PINCH_RATIO_THRESHOLD` in `script.js`
  (line ~15). Lower it if pinches trigger too easily, raise it if they don't
  trigger enough.
- Animation speed between stages is controlled by `GROWTH_SPEED`.
- Left/Right hand labels are corrected for the mirrored (selfie) view via
  `selfieMode: true`, so "Right" always means *your* right hand as you look
  at the screen, not the camera's raw left/right.
- Click **Reset** to clear the flower and start over.

## Possible next steps

- Support multiple flowers (one per detected hand) instead of a single shared one.
- Add sound effects on each stage transition.
- Swap the canvas-drawn flower for an SVG/Lottie animation for richer visuals.
- Persist "blossomed" flowers to a garden view across sessions.
