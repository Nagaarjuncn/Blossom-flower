/* ============================================================
   Gesture Flower Prototype
   - Uses MediaPipe Hands to track both hands from the webcam
   - State machine: NONE -> BUD -> FLOWER -> BLOSSOM
     * Any hand visible (raised in frame)      => BUD appears
     * RIGHT hand thumb+index pinch            => BUD becomes FLOWER
     * LEFT  hand thumb+index pinch            => FLOWER becomes BLOSSOM
   ============================================================ */

const videoElement = document.getElementById("input_video");
const canvasElement = document.getElementById("output_canvas");
const ctx = canvasElement.getContext("2d");
const statusEl = document.getElementById("status");
const resetBtn = document.getElementById("reset_btn");

// ---- Tunable constants ----
const PINCH_RATIO_THRESHOLD = 0.35; // thumb-index distance / palm-size ratio below which we call it a "pinch"
const GROWTH_SPEED = 0.06; // how fast the plant animates between stages (0-1 lerp per frame)

// ---- App state ----
const STAGES = { NONE: 0, BUD: 1, FLOWER: 2, BLOSSOM: 3 };
let stage = STAGES.NONE;
let growth = 0; // 0..1 animated progress within current stage transition
let plantX = 0.5; // normalized position (0..1) where the plant is drawn
let plantY = 0.6;
let lastHandSeenAt = 0;
const HAND_LOST_GRACE_MS = 800; // keep last known plant position briefly after hand disappears

// Smoothly track target growth per stage for nice animation
let targetGrowth = { [STAGES.NONE]: 0, [STAGES.BUD]: 0.33, [STAGES.FLOWER]: 0.66, [STAGES.BLOSSOM]: 1 };

resetBtn.addEventListener("click", () => {
  stage = STAGES.NONE;
  growth = 0;
});

function dist(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// Returns true if thumb tip (4) and index tip (8) are pinched together,
// normalized against the hand's own size (wrist(0) to middle-MCP(9)) so it
// works regardless of how close/far the hand is from the camera.
function isPinching(landmarks) {
  const thumbTip = landmarks[4];
  const indexTip = landmarks[8];
  const wrist = landmarks[0];
  const middleMcp = landmarks[9];
  const handScale = dist(wrist, middleMcp) || 0.0001;
  const pinchDist = dist(thumbTip, indexTip);
  return pinchDist / handScale < PINCH_RATIO_THRESHOLD;
}

function setStatus(text) {
  statusEl.textContent = text;
}

function onResults(results) {
  canvasElement.width = results.image.width;
  canvasElement.height = results.image.height;

  ctx.save();
  ctx.clearRect(0, 0, canvasElement.width, canvasElement.height);

  // Draw mirrored camera frame onto the canvas ourselves (so drawing + video line up perfectly)
  ctx.translate(canvasElement.width, 0);
  ctx.scale(-1, 1);
  ctx.drawImage(results.image, 0, 0, canvasElement.width, canvasElement.height);
  ctx.restore();

  const hands = results.multiHandLandmarks || [];
  const handednesses = results.multiHandedness || [];

  let rightPinch = false;
  let leftPinch = false;
  let anyHandVisible = hands.length > 0;
  let referenceLandmarks = null;

  for (let i = 0; i < hands.length; i++) {
    const landmarks = hands[i];
    const label = handednesses[i] && handednesses[i].label; // "Left" or "Right" (already selfie-corrected)
    const pinching = isPinching(landmarks);

    if (label === "Right") rightPinch = rightPinch || pinching;
    if (label === "Left") leftPinch = leftPinch || pinching;

    // Use whichever hand is currently active to anchor the plant position
    referenceLandmarks = landmarks;

    drawHandSkeleton(landmarks, pinching);
  }

  // ---- Update plant position (based on wrist of the most recently seen hand) ----
  if (referenceLandmarks) {
    // Mirror x because we mirrored the canvas for display
    plantX = 1 - referenceLandmarks[0].x;
    plantY = referenceLandmarks[0].y;
    lastHandSeenAt = performance.now();
  }

  const handRecentlySeen = performance.now() - lastHandSeenAt < HAND_LOST_GRACE_MS;

  // ---- State machine transitions ----
  if (anyHandVisible || handRecentlySeen) {
    if (stage === STAGES.NONE) {
      stage = STAGES.BUD;
    }
  } else {
    stage = STAGES.NONE;
  }

  if (stage === STAGES.BUD && rightPinch) {
    stage = STAGES.FLOWER;
  }

  if (stage === STAGES.FLOWER && leftPinch) {
    stage = STAGES.BLOSSOM;
  }

  // Animate growth toward the target for current stage
  const target = targetGrowth[stage];
  growth += (target - growth) * GROWTH_SPEED;

  drawPlant(plantX, plantY, stage, growth);

  updateStatusText(stage, rightPinch, leftPinch);
}

function updateStatusText(stage, rightPinch, leftPinch) {
  switch (stage) {
    case STAGES.NONE:
      setStatus("Raise a hand to plant a seed 🌱");
      break;
    case STAGES.BUD:
      setStatus("Bud growing — pinch your RIGHT thumb & index to bloom it into a flower");
      break;
    case STAGES.FLOWER:
      setStatus("Flower formed — pinch your LEFT thumb & index to make it blossom");
      break;
    case STAGES.BLOSSOM:
      setStatus("🌸 Full blossom! Click Reset to start over.");
      break;
  }
}

/* ---------------- Drawing helpers ---------------- */

function drawHandSkeleton(landmarks, pinching) {
  if (window.drawConnectors && window.HAND_CONNECTIONS) {
    // Landmarks are already in normalized [0,1] video space; canvas is mirrored
    // via ctx transform when we drew the frame, so we mirror the x here too.
    const mirrored = landmarks.map((p) => ({ x: 1 - p.x, y: p.y, z: p.z }));
    drawConnectors(ctx, mirrored, HAND_CONNECTIONS, {
      color: pinching ? "#ffca28" : "#80deea",
      lineWidth: 2,
    });
    drawLandmarks(ctx, mirrored, {
      color: pinching ? "#ff7043" : "#4fc3f7",
      lineWidth: 1,
      radius: 2,
    });
  }
}

// stage: current STAGES value, growth: 0..1 progress within/through stages
function drawPlant(nx, ny, stage, growth) {
  if (stage === STAGES.NONE) return;

  const w = canvasElement.width;
  const h = canvasElement.height;
  const x = nx * w;
  const y = ny * h;
  const baseSize = Math.min(w, h) * 0.18;

  ctx.save();
  ctx.translate(x, y);

  // Stem
  ctx.strokeStyle = "#4caf50";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, baseSize * 0.6);
  ctx.stroke();

  // growth spans 0..1 across BUD(0.33)->FLOWER(0.66)->BLOSSOM(1)
  // Map to a 0..1 "openness" for petals, and a 0..1 "size" for overall scale.
  const openness = Math.max(0, (growth - 0.33) / (1 - 0.33)); // 0 until past bud stage
  const size = 0.5 + growth * 0.5; // buds are smaller, blossom is biggest

  const petalColor = growth < 0.66 ? "#e91e63" : "#ff4081";
  const petalCount = 8;
  const petalLength = baseSize * 0.55 * size;
  const petalWidth = baseSize * 0.22 * size;
  const spread = Math.min(1, openness); // 0 = closed bud, 1 = fully open

  for (let i = 0; i < petalCount; i++) {
    const angle = (i / petalCount) * Math.PI * 2;
    const petalAngle = angle;
    const openFactor = 0.15 + 0.85 * spread; // closed petals hug center, open petals spread out
    ctx.save();
    ctx.rotate(petalAngle);
    ctx.translate(0, -petalLength * 0.5 * openFactor);
    ctx.fillStyle = petalColor;
    ctx.beginPath();
    ctx.ellipse(0, 0, petalWidth * (0.6 + 0.4 * spread), petalLength * (0.5 + 0.5 * spread), 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Center of flower
  ctx.beginPath();
  ctx.fillStyle = growth >= 1 ? "#ffd54f" : "#8d6e63";
  ctx.arc(0, 0, baseSize * 0.14 * size, 0, Math.PI * 2);
  ctx.fill();

  // Sparkle effect at full blossom
  if (growth > 0.95) {
    drawSparkles(baseSize);
  }

  ctx.restore();
}

let sparkleTime = 0;
function drawSparkles(baseSize) {
  sparkleTime += 0.05;
  ctx.save();
  ctx.fillStyle = "rgba(255,255,255,0.8)";
  for (let i = 0; i < 6; i++) {
    const a = sparkleTime + (i / 6) * Math.PI * 2;
    const r = baseSize * 0.9;
    const sx = Math.cos(a) * r;
    const sy = Math.sin(a) * r;
    ctx.beginPath();
    ctx.arc(sx, sy, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/* ---------------- MediaPipe setup ---------------- */

const hands = new Hands({
  locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
});

hands.setOptions({
  maxNumHands: 2,
  modelComplexity: 1,
  minDetectionConfidence: 0.6,
  minTrackingConfidence: 0.6,
  selfieMode: true, // so "Left"/"Right" labels match the mirrored view the user sees
});

hands.onResults(onResults);

const camera = new Camera(videoElement, {
  onFrame: async () => {
    await hands.send({ image: videoElement });
  },
  width: 960,
  height: 720,
});

setStatus("Requesting camera permission...");

camera
  .start()
  .then(() => setStatus("Camera ready — raise a hand!"))
  .catch((err) => {
    console.error(err);
    setStatus("Could not access camera. Check permissions and reload.");
  });
